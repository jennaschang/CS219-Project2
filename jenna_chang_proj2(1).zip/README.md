## CS 219
**Name:** Jenna Chang

**Due Date:** 2 November 2023

**Project:** Programming Project 2

## Running the program
Type the following:
```
gcc jenna_chang_proj2.c
./a.out
```
## Program's working process
1. First the program opens a file to read and assigns it to a pointer. If the file opened is NULL, the program returns 0 and the entire program ends. If the file is successfully read, then the program moves on.
2. The program assigns variable "opCount" the value that is returned by the function "getFile".
3. The function "getFile" passes in the file pointer, a 2D array of chars, and two arrays of ints. It proceeds to use fscanf in order to read from file and assign the appropriate values to the appropriate arrays. During each loop the "index" variable is incremented. The loop finishes when there are no more variables to be read from file. The function then returns the "index" variable.
4. After the program has executed the "getFile" function, a for loop is executed. The for loop will only iterate as many times as the "opCount" variable will allow. For each loop, a string compare function will compare the operation stored in the 2D array with a the operations avalible to perform. If it finds a valid operation, it will perform said operation before displaying to terminal the two operands and the result of the operation.
5. If the operation being performed has an appended "S" char in addition to the regular operation call, then it will trigger flags for the result. If the resultant operand is unsigned, then the negative flag is 0. If it is signed, and the MSB is between the range of 8-F, then the negative flag is 1. Additionally, if the resultant operand is equal to 0, then the zero flag is 1. If it is not equal to 0, then the zero flag is 0.
6. Once the for loop is done executing, the program closes the file and returns 0.

## Results
ADDS 0x0aaa5555 0x0555aaaa: 0x0fffffff

ADD 0xffffffff 0x00000001: 0x00000000

ADDS 0x00001234 0x00008765: 0x00009999

ADD 0x72df9901 0x2e0b484a: 0xa0eae14b

ANDS 0x0aaa5555 0x0555aaaa: 0x00000000

AND 0xffffffff 0x00000001: 0x00000001

ANDS 0x00001234 0x00008765: 0x00000224

AND 0x72df9901 0x2e0b484a: 0x220b0800

ASRS 0x0aaa5555 0x00000001: 0x05552aaa

ASR 0xffffffff 0x00000002: 0xffffffff

ASRS 0x00001234 0x00000003: 0x00000246

ASR 0x72df9901 0x00000004: 0x072df990

LSRS 0x0aaa5555 0x00000001: 0x05552aaa

LSR 0xffffffff 0x00000002: 0x3fffffff

LSRS 0x00001234 0x00000003: 0x00000246

LSR 0x72df9901 0x00000004: 0x072df990

LSL 0x0aaa5555 0x00000001: 0x1554aaaa

LSLS 0xffffffff 0x00000002: 0xfffffffc

LSL 0x00001234 0x00000003: 0x000091a0

LSLS 0x72df9901 0x00000004: 0x2df99010

NOT 0x0aaa5555: 0xf555aaaa

NOTS 0xffffffff: 0x00000000

NOT 0x00008765: 0xffff789a

NOTS 0x2e0b484a: 0xd1f4b7b5

ORR 0x0aaa5555 0x0555aaaa: 0x0fffffff

ORRS 0xffffffff 0x00000001: 0xffffffff

ORR 0x00001234 0x00008765: 0x00009775

ORRS 0x72df9901 0x2e0b484a: 0x7edfd94b

SUB 0x0aaa5555 0x0555aaaa: 0x0554aaab

SUBS 0xffffffff 0x00000001: 0xfffffffe

SUB 0x00008765 0x00001234: 0x00007531

SUBS 0x72df9901 0x2e0b484a: 0x44d450b7

XOR 0x0aaa5555 0x0555aaaa: 0x0fffffff

XORS 0xffffffff 0x00000001: 0xfffffffe

XOR 0x00008765 0x00001234: 0x00009551

XORS 0x72df9901 0x2e0b484a: 0x5cd4d14b