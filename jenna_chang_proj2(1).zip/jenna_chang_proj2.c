/**
 * @file jenna_chang_proj2.c
 * @author Jenna Chang
 * @date 30 October 2023
 * @class CS 219.1001
*/

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#define OP 50

int getFile(FILE*, char [][OP], uint32_t [], uint32_t []);

int main(){
   FILE *opFile;
   opFile = fopen("Programming-Project-2.txt", "r");
   	if(opFile == NULL){
		printf("Cannot open file.\n");
		return 0;
    }
    else{
        int opCount;
        uint32_t r1[OP], r2[OP], r3[OP];
        int32_t r4[OP];

        char operations[OP][OP];

        char add[OP] = "ADD";
        char adds[OP] = "ADDS";
        char and[OP] = "AND";
        char ands[OP] = "ANDS";
        char asr[OP] = "ASR";
        char asrs[OP] = "ASRS";
        char lsr[OP] = "LSR";
        char lsrs[OP] = "LSRS";
        char lsl[OP] = "LSL";
        char lsls[OP] = "LSLS";
        char not[OP] = "NOT";
        char nots[OP] = "NOTS";
        char orr[OP] = "ORR";
        char orrs[OP] = "ORRS";
        char sub[OP] = "SUB";
        char subs[OP] = "SUBS";
        char xor[OP] = "XOR";
        char xors[OP] = "XORS";

        opCount = getFile(opFile, operations, r1, r2);

        for(int j = 0; j < opCount; j++){
            if(strcmp(add, operations[j]) == 0 ||
               strcmp(adds, operations[j]) == 0 ){
                r3[j] = r1[j] + r2[j];
                printf("%s 0x%08x 0x%08x: 0x%08x\n", operations[j], r1[j], r2[j], r3[j]);
                printf("\n");
            }
            else if(strcmp(and, operations[j]) == 0 ||
                    strcmp(ands, operations[j]) == 0 ){
                r3[j] = r1[j] & r2[j];
                printf("%s 0x%08x 0x%08x: 0x%08x\n", operations[j], r1[j], r2[j], r3[j]);
                printf("\n");
            }
            else if(strcmp(asr, operations[j]) == 0 ||
                    strcmp(asrs, operations[j]) == 0 ){
                r4[j] = (signed int)r1[j] >> (signed int)r2[j];
                printf("%s 0x%08x 0x%08x: 0x%08x\n", operations[j], r1[j], r2[j], r4[j]);
                printf("\n");
            }
            else if(strcmp(lsr, operations[j]) == 0 ||
                    strcmp(lsrs, operations[j]) == 0 ){
                r3[j] = r1[j] >> r2[j];
                printf("%s 0x%08x 0x%08x: 0x%08x\n", operations[j], r1[j], r2[j], r3[j]);
                printf("\n");
            }
            else if(strcmp(lsl, operations[j]) == 0 ||
                    strcmp(lsls, operations[j]) == 0 ){
                r3[j] = r1[j] << r2[j];
                printf("%s 0x%08x 0x%08x: 0x%08x\n", operations[j], r1[j], r2[j], r3[j]);
                printf("\n");
            }
            else if(strcmp(not, operations[j]) == 0 ||
                    strcmp(nots, operations[j]) == 0 ){
                r3[j] = ~r1[j];
                printf("%s 0x%08x: 0x%08x\n", operations[j], r1[j], r3[j]);
                printf("\n");
            }
            else if(strcmp(orr, operations[j]) == 0 ||
                    strcmp(orrs, operations[j]) == 0 ){
                r3[j] = r1[j] | r2[j];
                printf("%s 0x%08x 0x%08x: 0x%08x\n", operations[j], r1[j], r2[j], r3[j]);
                printf("\n");
            }
            else if(strcmp(sub, operations[j]) == 0 ||
                    strcmp(subs, operations[j]) == 0 ){
                r3[j] = r1[j] - r2[j];
                printf("%s 0x%08x 0x%08x: 0x%08x\n", operations[j], r1[j], r2[j], r3[j]);
                printf("\n");
            }
            else if(strcmp(xor, operations[j]) == 0 ||
                    strcmp(xors, operations[j]) == 0 ){
                r3[j] = r1[j] ^ r2[j];
                printf("%s 0x%08x 0x%08x: 0x%08x\n", operations[j], r1[j], r2[j], r3[j]);
                printf("\n");
            }
            else{
                printf("INVALID OPERATION\n");
            }
        }
    }
   fclose(opFile);
    return 0;
}

int getFile(FILE* opFile, char operations[][OP], uint32_t opOne[], uint32_t opTwo[]){
	int index = 0;
	while(fscanf(opFile, "%s", operations[index]) == 1){
        if(fscanf(opFile, "%x", &opOne[index]) == 1){
            if(fscanf(opFile, "%x", &opTwo[index]) == 1){
                index++;
            }
            else{
                index++;
            }
        }
    }
	return index;
}